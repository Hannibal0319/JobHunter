const NoMatch = () =>{
    return(
        <div className="font-bold text-3xl flex h-full w-full"><span className="mx-auto my-32"> 404 Page not Found</span></div>
    );
}

export default NoMatch